from flask import Flask, render_template, request
import logging

app = Flask(__name__)
app.logger.setLevel(logging.INFO)

@app.route('/mypage/me')
def my_page_me():
    return render_template('me/index.html')

@app.route('/mypage/contact', methods=['GET', 'POST'])
def my_page_contact():
    if request.method == 'POST':
        message = request.form.get('message')
        app.logger.info(f"Zapisano wiadomość: {message}")

    return render_template('contact/contact.html')

if __name__ == '__main__':
    app.run(debug=True)