class Config:
    SECRET_KEY = '123'  # Klucz do obsługi formularzy
    SQLALCHEMY_DATABASE_URI = 'sqlite:///domowa_biblioteka.db'  # Ścieżka do bazy danych SQLite
    SQLALCHEMY_TRACK_MODIFICATIONS = False
