from flask_wtf import FlaskForm
from wtforms import StringField, BooleanField, SubmitField, DateField
from wtforms.validators import DataRequired, Optional

class BookForm(FlaskForm):
    title = StringField('Tytuł książki', validators=[DataRequired()])
    author = StringField('Autor', validators=[DataRequired()])
    on_shelf = BooleanField('Na półce')
    loan_date = DateField('Data wypożyczenia', validators=[Optional()])
    return_date = DateField('Data zwrotu', validators=[Optional()])
    submit = SubmitField('Zapisz zmiany')

    def populate_fields(self, book):
        self.title.data = book.title
        # Ustaw wartość pola autora na listę wszystkich autorów książki, oddzielając ich przecinkiem
        self.author.data = ', '.join([author.name for author in book.authors])
        self.on_shelf.data = book.on_shelf
        self.loan_date.data = book.loan_date
        self.return_date.data = book.return_date


