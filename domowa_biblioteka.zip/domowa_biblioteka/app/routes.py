from flask import render_template, redirect, url_for
from app import app, db
from app.forms import BookForm
from app.models import Book, Author

@app.route('/')
def index():
    books = Book.query.all()
    return render_template('index.html', title='Home', books=books)

@app.route('/dodaj_ksiazke', methods=['GET', 'POST'])
def dodaj_ksiazke():
    form = BookForm()
    if form.validate_on_submit():
        title = form.title.data
        author_name = form.author.data
        author = Author.query.filter_by(name=author_name).first()
        if not author:
            author = Author(name=author_name)
            db.session.add(author)
            db.session.commit()
        on_shelf = form.on_shelf.data
        loan_date = form.loan_date.data
        return_date = form.return_date.data
        book = Book(title=title, on_shelf=on_shelf, loan_date=loan_date, return_date=return_date)
        book.authors.append(author)
        db.session.add(book)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('dodaj_ksiazke.html', title='Dodaj książkę', form=form)

@app.route('/edytuj_ksiazke/<int:book_id>', methods=['GET', 'POST'])
def edytuj_ksiazke(book_id):
    book = Book.query.get_or_404(book_id)
    form = BookForm(obj=book)
    if form.validate_on_submit():
        book.title = form.title.data
        author_name = form.author.data
        author = Author.query.filter_by(name=author_name).first()
        if not author:
            author = Author(name=author_name)
            db.session.add(author)
            db.session.commit()
        book.authors = [author]
        book.on_shelf = form.on_shelf.data
        book.loan_date = form.loan_date.data
        book.return_date = form.return_date.data
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('edytuj_ksiazke.html', title='Edytuj książkę', form=form, book=book)

@app.route('/usun_ksiazke/<int:book_id>', methods=['POST'])
def usun_ksiazke(book_id):
    book = Book.query.get_or_404(book_id)
    db.session.delete(book)
    db.session.commit()
    return redirect(url_for('index'))
