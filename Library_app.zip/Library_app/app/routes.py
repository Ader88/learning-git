from flask import request, flash, render_template, redirect, url_for, Blueprint, abort
from flask_restful import Api, Resource, reqparse
from collections import Counter
from app.models import Book
from app.forms import BookForm

import logging

logger = logging.getLogger(__name__)

books_bp = Blueprint('books', __name__)
api = Api(books_bp)

books = [
    Book(id=1, title="Harry Potter", author="J.K. Rowling", description="Przygody młodego czarodzieja", cover_color="Niebieski"),
    Book(id=2, title="Zabić drozda", author="Harper Lee", description="Klasyczna powieść osadzona w południowych Stanach Zjednoczonych", cover_color="Czerwony"),
    Book(id=3, title="Wielki Gatsby", author="F. Scott Fitzgerald", description="Historia lat dwudziestych XX wieku", cover_color="Żółty"),
    Book(id=4, title="1984", author="George Orwell", description="Dystopijna powieść o totalitaryzmie", cover_color="Szary"),
    Book(id=5, title="Duma i uprzedzenie", author="Jane Austen", description="Klasyczna powieść obyczajowa o miłości", cover_color="Zielony"),
]

def sort_books_by_cover_color():
    cover_colors = [book.cover_color for book in books]
    counter_result = Counter(cover_colors).most_common(1)
    dominant_color = counter_result[0][0] if counter_result else None
    sorted_books = sorted(books, key=lambda x: x.cover_color != dominant_color)
    return sorted_books

@books_bp.route('/ksiazki/', methods=['GET', 'POST'])
def lista_ksiazek():
    form = BookForm()
    if form.validate_on_submit():
        nowa_ksiazka = Book(
            id=len(books) + 1,
            title=form.title.data,
            author=form.author.data,
            description=form.description.data,
            cover_color=form.cover_color.data
        )
        books.append(nowa_ksiazka)
        logger.info(f"Nowa książka dodana: {nowa_ksiazka.title} - {nowa_ksiazka.author}")
        flash(f"Nowa książka dodana: {nowa_ksiazka.title} - {nowa_ksiazka.author}", 'success')
        return redirect(url_for('books.lista_ksiazek'))

    sorted_books = sort_books_by_cover_color()
    return render_template('index.html', form=form, books=sorted_books)

@books_bp.route('/ksiazki/szczegoly/<int:book_id>', methods=['GET', 'POST'])
def szczegoly_ksiazki(book_id):
    book = next((b for b in books if b.id == book_id), None)

    if book is not None:
        form = BookForm(request.form, obj=book)
        if form.validate_on_submit():
            book.title = form.title.data
            book.author = form.author.data
            book.description = form.description.data
            book.cover_color = form.cover_color.data
            flash(f"Informacje o książce zaktualizowane: {book.title} - {book.author}", 'info')

        return render_template('book_details.html', book=book, book_id=book_id, form=form)
    else:
        abort(404)

@books_bp.route('/ksiazki/usun/<int:book_id>', methods=['POST'])
def usun_ksiazke(book_id):
    book = next((b for b in books if b.id == book_id), None)

    if book is not None:
        books.remove(book)
        logger.info(f"Usunięto książkę: {book.title} - {book.author}")
        flash(f"Usunięto książkę: {book.title} - {book.author}", 'success')
    else:
        abort(404)

    return redirect(url_for('books.lista_ksiazek'))

class BooksApi(Resource):
    def get(self):
        sorted_books = sort_books_by_cover_color()
        return {'books': [book.to_dict() for book in sorted_books]}

    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('title', type=str, required=True)
        parser.add_argument('author', type=str, required=True)
        parser.add_argument('description', type=str, required=True)
        parser.add_argument('cover_color', type=str, required=True)
        args = parser.parse_args()

        nowa_ksiazka = Book(
            id=len(books) + 1,
            title=args['title'],
            author=args['author'],
            description=args['description'],
            cover_color=args['cover_color']
        )
        books.append(nowa_ksiazka)
        logger.info(f"Nowa książka dodana: {nowa_ksiazka.title} - {nowa_ksiazka.author}")
        flash(f"Nowa książka dodana: {nowa_ksiazka.title} - {nowa_ksiazka.author}", 'success')
        return {'message': 'Książka dodana pomyślnie'}, 201

api.add_resource(BooksApi, '/api/ksiazki')
