from flask import Flask

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'klucz_tajny'

    from app.routes import books_bp
    app.register_blueprint(books_bp)

    return app
