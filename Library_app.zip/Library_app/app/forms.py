from flask_wtf import FlaskForm
from wtforms import StringField
from wtforms.validators import DataRequired

class BookForm(FlaskForm):
    title = StringField('Tytuł', validators=[DataRequired()])
    author = StringField('Autor', validators=[DataRequired()])
    description = StringField('Opis', validators=[DataRequired()])
    cover_color = StringField('Kolor okładki', validators=[DataRequired()])
