from dataclasses import dataclass

@dataclass
class Book:
    id: int
    title: str
    author: str
    description: str
    cover_color: str

    def to_dict(self):
        return {'id': self.id, 'title': self.title, 'author': self.author, 'description': self.description, 'cover_color': self.cover_color}
