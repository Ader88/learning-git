# Library App

Aplikacja do zarządzania biblioteką domową.

## Instalacja

1. Stwórz wirtualne środowisko:

    ```bash
    python -m venv venv
    source venv/bin/activate  # Dla systemu Linux / MacOS
    venv\Scripts\activate  # Dla systemu Windows
    ```

2. Zainstaluj zależności:

    ```bash
    pip install -r requirements.txt
    ```

3. Uruchom aplikację:

    ```bash
    python run.py
    ```

## Użycie

1. Wejdź na stronę: http://127.0.0.1:5000/ksiazki/
2. Dodawaj, edytuj i usuwaj książki z biblioteki.

## RESTful API

Aplikacja udostępnia API do zarządzania książkami:

- `GET /api/books`: Pobierz listę wszystkich książek.
- `GET /api/books/<int:book_id>`: Pobierz szczegóły książki o danym ID.
- `POST /api/books`: Dodaj nową książkę.
- `PUT /api/books/<int:book_id>`: Edytuj książkę o danym ID.
- `DELETE /api/books/<int:book_id>`: Usuń książkę o danym ID.


Aby sprawdzić działanie API, możesz użyć polecenia curl w terminalu.

> Pobierz listę wszystkich książek - (bash): curl http://127.0.0.1:5000/api/ksiazki

> Pobierz szczegóły książki o danym ID (zastąp <book_id> właściwym numerem ID książki) -

(bash): curl -X POST -H "Content-Type: application/json" -d '{"title":"Nowa Książka","author":"Autor XYZ","description":"Opis książki","cover_color":"Czerwony"}' http://127.0.0.1:5000/api/ksiazki

> Dodaj nową książkę (zastąp wartościami odpowiednimi dla nowej książki) -

(bash): curl -X POST -H "Content-Type: application/json" -d '{"title":"Nowa Książka","author":"Autor XYZ","description":"Opis książki","cover_color":"Czerwony"}'

> Edytuj książkę o danym ID (zastąp <book_id> i podaj nowe dane książki) - 

(bash): curl -X PUT -H "Content-Type: application/json" -d '{"title":"Nowy Tytuł","author":"Nowy Autor","description":"Nowy Opis","cover_color":"Nowy Kolor"}' http://127.0.0.1:5000/api/ksiazki/<book_id>

> Usuń książkę o danym ID (zastąp <book_id>) -

(bash): curl -X DELETE http://127.0.0.1:5000/api/ksiazki/<book_id>

Upewnij się, że serwer Flask działa lokalnie na porcie 5000 pod adresem http://127.0.0.1:5000 przed użyciem tych poleceń. Zastąp <book_id> rzeczywistym numerem ID książki do operacji GET, PUT i DELETE.